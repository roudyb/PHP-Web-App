<?php
/**
* 
*/
 include ('User.class.php');
 
class LogIn
{

	public function getMyData() {

		session_start();
		// $_POST (predefined variable) is looking for the vars from the html form
		// method="post" and inside the [] is from the form Username: name="username" 
		if (isset($_POST['username'])) {
    		// Set variables to represent data from database - hardcoded vars
			$dbUsname = "Peter";
			$dbPassword = "test1";
			
			// This var is used for the SESSION cookie $uid
			$uid = "1111";
	
			// Set the posted data from the form into local variables
			// strip_tags function removes html tags
			$usname = strip_tags($_POST['username']);
			$paswd = strip_tags($_POST['password']);
	
			// Check if the username and the password they entered was correct
			// if the entered username == the hardcoded dbUsname && the entered password
			// == dbPassword, continue if statement
		if ($usname == $dbUsname && $paswd == $dbPassword) {
			// Set a session cookie from the html form Username: name="username"
			// The form element 'username' is defined to SESSION name $usname
			$_SESSION['username'] = $usname;
			// The html form id="form" is set to the predefined var $uid defined to "1111" for
			// the SESSION
			$_SESSION['id'] = $uid;
			// Now direct to users feed set in the User.class.php file
			header("Location: User.class.php");
			// If the information entered is incorrect display an error message
		} else {
			echo "<h2>The username or password combination that you entered is incorrect.
			<br /> Please try again.</h2>";
			}
	
		}
		
	}
}

?>