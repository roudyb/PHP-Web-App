<?php
/*********************************************************************
* Author: Roudy Courser
* Assignment: WE4.0 PHP Web App Assignment, Digital Skills Academy
* Student ID: D15128554
* Date : 2016/05/22
* Ref: 	Assistance from fellow students Brian Conlon & Callum McLeman
**********************************************************************/
 
class User{

	function __construct(){

	}
	

	public function getPassed() {
		echo "Passed - hit back button to return home";
	}

	public function getFailed(){
		echo "Failed - hit back button to return home";
	}


}
?>
